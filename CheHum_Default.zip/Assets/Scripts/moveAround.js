﻿#pragma strict

var speed = 3.0;
var rotateSpeed = 3.0;
var fireBallPower : float = 2000.0f;
var spawnPoint:Transform;
var bulletPrefab:Transform;

function Update () {
	var controller : CharacterController = GetComponent(CharacterController);

	transform.Rotate( 0, Input.GetAxis("Horizontal")* rotateSpeed, 0);

	var forward = transform.TransformDirection(Vector3.forward);
	var curSpeed = speed * Input.GetAxis("Vertical");
	controller.SimpleMove(forward * curSpeed);

	if(Input.GetButtonDown("Jump")){
		var bullet = Instantiate(bulletPrefab, spawnPoint.position, transform.rotation);
		var rb : Rigidbody = bullet.GetComponent("Rigidbody");
		rb.AddForce(transform.forward * fireBallPower);
	}
}


 